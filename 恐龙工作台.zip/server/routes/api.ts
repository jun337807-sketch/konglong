import { Router } from 'express';
import { getBucketName, getTosClient } from '../services/tosService.js';
import multer from 'multer';
import { getDb } from '../db/database.js';

const router = Router();
const upload = multer({ storage: multer.memoryStorage() });

// 1. Get Project List (from DB)
router.get('/projects', async (req, res) => {
  try {
    const db = await getDb();
    const projects = await db.all('SELECT id, name, updatedAt FROM projects ORDER BY updatedAt DESC');
    res.json({ success: true, projects });
  } catch (err: any) {
    console.error('List projects error:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// 2. Save Project
router.post('/projects/:id', async (req, res) => {
  const { id } = req.params;
  const { name, projectData } = req.body; 
  try {
    const db = await getDb();
    const now = Date.now();
    
    // Check if project exists
    const existing = await db.get('SELECT id FROM projects WHERE id = ?', [id]);
    
    if (existing) {
        await db.run(
            'UPDATE projects SET name = ?, projectData = ?, updatedAt = ? WHERE id = ?',
            [name || '未命名项目', JSON.stringify(projectData), now, id]
        );
    } else {
        await db.run(
            'INSERT INTO projects (id, name, projectData, updatedAt) VALUES (?, ?, ?, ?)',
            [id, name || '未命名项目', JSON.stringify(projectData), now]
        );
    }
    
    res.json({ success: true, message: 'Saved successfully' });
  } catch (err: any) {
    console.error('Save project error:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// 3. Get Single Project
router.get('/projects/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const db = await getDb();
    const project = await db.get('SELECT projectData FROM projects WHERE id = ?', [id]);
    
    if (!project) {
        return res.status(404).json({ success: false, error: 'Project not found' });
    }
    
    res.json({ success: true, projectData: JSON.parse(project.projectData) });
  } catch (err: any) {
     console.error('Get project error:', err);
     res.status(500).json({ success: false, error: err.message });
  }
});

// 4. Delete Project
router.delete('/projects/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const db = await getDb();
    await db.run('DELETE FROM projects WHERE id = ?', [id]);
    res.json({ success: true });
  } catch(err: any) {
    console.error('Delete project error:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// 5. TOS File Upload 
router.post('/upload', upload.single('file'), async (req, res) => {
  if (!req.file) return res.status(400).json({ success: false, error: 'No file' });
  try {
    const client = getTosClient();
    const extension = req.file.originalname.split('.').pop();
    const key = `uploads/${Date.now()}_${Math.random().toString(36).substring(7)}.${extension}`;
    
    await client.putObject({
      bucket: getBucketName(),
      key: key,
      body: req.file.buffer,
    });
    
    const url = `https://${getBucketName()}.tos-cn-beijing.volces.com/${key}`;
    res.json({ success: true, url });
  } catch (err: any) {
    console.error('Upload Error', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

export default router;
